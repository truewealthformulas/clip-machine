# Instructions for Claude Code

You are setting up and running an automatic short-video channel for the person you're talking to.
Read `README.md`, `SETUP.md` and `LESSONS.md` first, fully.

## First conversation: ask, don't assume
1. What content do they clip? Whose channel, and do they have the rights?
2. Which accounts will it post to, and do they already have developer apps for Meta, YouTube and TikTok?
3. What is the offer or call to action (a keyword people comment, a link, nothing)?
4. How many posts a day? (4-6 is a good start.)
5. Do they want to review the first clips before anything goes live? (Yes: use `"test": true` plans.)

## Working rules
- **One heavy job at a time on their computer.** Transcription and rendering are CPU-heavy. Never run several in parallel locally; the cloud factory is where parallel work belongs.
- **Watch the usage limit.** Check it before any big step and tell them the number.
- **Never handle their passwords or keys.** They paste secrets into GitHub themselves.
- **Verify the artifact, not the exit code.** A command that says "success" has lied many times. Read back the file, the upload and the live post.
- **Show, don't describe.** For any visual choice (captions, thumbnails), render real mockups and open them.

## Writing clip plans (the one judgment step)
Plans live in `factory/plans/<key>.json`:
```json
{"source": "<episode id>.mp4", "brand": "KT_TOPIC", "test": false,
 "clips": [{"slug": "SHORT-NAME", "in": 211.6, "out": 291.0,
            "hook": ["How a snowstorm", "made me money"],
            "caption": "Story in short paragraphs...\n\n#tags",
            "cta_kind": "offer"}]}
```
1. Run the factory, then decrypt the transcripts (`pipeline/kt_factory_transcripts.py`) and read them.
2. Choose stories that **stand alone**: open on the want or the setup, and end on the payoff line. The last sentence should be the punchline.
3. Prefer **methods and stories** (how rich people buy houses) over warnings (a mortgage is a scam). In this system's data, methods earned 30-40× more shares and saves.
4. Hooks: 6 words or fewer, direct ("Why / How / What …"). They are linted, and failing ones are dropped.
5. Captions: tell the story in 4-6 short paragraphs and end on a question or a lesson (400-600 characters). A caption is not a label.
6. Take cut times from the transcript. The cloud snaps them to word-level sentence edges and drops anything that still fails.
7. **Give each episode its own `brand` folder.** The scheduler allows at most 2 posts per folder per day, to keep the feed mixed.
8. Write a month of plans in one sitting, and the machine runs for a month.
