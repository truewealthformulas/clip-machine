# Lessons - each one cost real posts to learn

## Verification
- **"Success" is not verification.** Uploads that returned 0 had broken files, "posted" clips weren't on the account, and TikTok said "uploaded" before it had delivered anything. Always read back the artifact: the file, the URL (HTTP 200 plus size match), the live post.
- **The output's size proves nothing about quality.** Every clip renders at 1080×1920, even from a 360p source that looks like mush. Check the *source* resolution (1080p+) before cutting.
- **Whisper cannot referee whisper.** Check captions against the audio waveform (pauses), not against a second transcription.

## Clip edges (the #1 thing viewers notice)
- A clip must **open on the first word of a sentence** and **end on the payoff line**. Pauses are where people breathe, not where ideas end.
- Transcripts need punctuation to find sentences. Whisper only punctuates when given a punctuated `--prompt`, but **never use a prompt for the word-timing pass**: it compresses the timestamps and captions drift by seconds.
- Snapping cuts to silence can land on a tiny pause *inside* a sentence. After rendering, listen to the first seconds and compare them with the planned sentence (`opens_wrong` in `kt_batch_build.py`).
- Check that the next sentence doesn't *complete* the last one ("…and that's why…"). A clip that ends on a setup is broken.

## Captions and hooks
- Caption breaks matter as much as timing. Don't split numbers ("$450" / "million") or names, don't jam two sentences into one caption, and hold each caption long enough to read.
- Hooks: 6 words or fewer, held 4-5 seconds, direct ("Why / How / What …"), never a riddle.
- Keep text inside the phone's safe area: roughly 10% gets cropped on each side, plus the app bars top and bottom.

## Posting
- Duplicate *captions* are what get accounts flagged, not duplicate videos. Freeze a post's identity at creation (`caption_at_post`) and never re-identify posts by text you might later edit.
- Instagram and Facebook: alternate which one carries the comment-keyword call to action, so the same clip never reads identically on both.
- Facebook dedupes: re-uploading the same video returns the old reel. Use that as a duplicate detector.
- The scheduler caps 2 posts per source folder per day. Give every episode its own folder.
- Posting runs every ~20 min on GitHub cron, which can lag by hours under load. Slots are targets, not promises.

## Operations
- One heavy job (transcribe or render) at a time on a laptop. Parallel work belongs in the cloud.
- A queue that silently runs dry is the worst failure. Keep the run-out day on a calendar and an email alarm under 3 days (`queue_alarm.py`).
- Parallel jobs must never write the same file. Give one writer per shared file (manifest, index), and put temp files in per-process folders.
- A public repo must never host other people's full videos. Encrypt stored sources (`FACTORY_KEY`).

## What performs
- Methods and stories ("How rich people buy houses") beat warnings ("A mortgage is a scam"). Shares and saves separated a 200K-view clip from the rest, not watch time.
- A question at the end earns comments. Keep a soft keyword line under it too, so a viral clip still leads somewhere.
- Full-screen video beat letterboxed video massively in early tests. Test any new layout with Instagram Trial Reels before switching.
