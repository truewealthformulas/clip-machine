# Clip Machine: an automatic short-video channel

It turns long videos (podcasts, interviews, talks) into finished vertical clips.
Every clip gets captions, a hook and a description, and a check that it starts and ends cleanly.
The system posts them on a schedule to Instagram, Facebook, YouTube Shorts and TikTok.
It measures how they do, and it warns you before the queue runs out.
It runs free on GitHub, with your computer switched off.

It was built and battle-tested running real channels for weeks, with thousands of posts and every failure found and fixed.
This kit is that system with the owner's accounts, content and data removed.

## What it does, end to end

```
 source videos ──► STOCK ──► TRANSCRIBE ──► PLAN ──► BUILD ──► QUEUE ──► POST ──► MEASURE
 (a channel)     download   whisper,      clip      render +  upload    4-6/day   views,
                 HD only,   punctuated    choices   checks    to a      on every  shares,
                 encrypted  transcript    (JSON)    (cloud,   GitHub    platform  saves
                                                    parallel) release
```

- **factory/** runs the clip factory on GitHub Actions:
  - pulls source episodes (HD only), stored **encrypted** so a public repo never re-hosts anyone's video
  - transcribes them with whisper.cpp
  - builds clips from *plans* (JSON files saying which moments to cut), several servers in parallel
- **pipeline/** holds the clip engine (`kt_render.py` and friends). A plan goes in; a finished 1080×1920 clip comes out, and it must pass every gate:
  - hook of 6 words or fewer
  - ending on a finished sentence (no mid-sentence cuts, no running into ads)
  - word-level captions checked against the actual waveform
  - opening on the planned sentence
  - source video 1080p or better
- **machine/engine/** holds the posting machine. It schedules the queue into daily slots, posts to each platform, writes platform-specific calls to action, and audits that posts really exist.
- **machine/measure.py** records views, likes, shares, saves and watch time for every post, every 6 hours.
- **machine/queue_alarm.py and build_pages.py** give you a calendar feed with a "clips run out" day, an email alert under 3 days, and a dashboard page listing each clip's caption, ready for TikTok.

## What it costs
$0. GitHub Actions (public repo), GitHub Releases (media) and GitHub Pages (dashboard) are free.
Transcription runs on GitHub's servers.

## The one human step
Choosing *which* moments become clips is judgment work. You (or your Claude Code session) write plan files from the transcripts.
Do a batch of plans and the machine runs on its own for weeks.
`CLAUDE.md` tells your Claude how to write good plans.

## Start here
1. Read `SETUP.md`: accounts, keys, and the order to turn things on.
2. Give this whole folder to Claude Code. It reads `CLAUDE.md` and walks you through it.
3. Read `LESSONS.md` before you change anything. Every rule in it cost real posts to learn.
