# Roadmap

## Working today
- Cloud clip factory: stock (HD only, encrypted), transcribe, plan-driven build in parallel shards, one-writer queue.
- Posting to Instagram, Facebook, YouTube and TikTok (inbox), with per-platform calls to action and the Instagram/Facebook alternation.
- Measurement every 6h; calendar run-out event; email alarm; caption dashboard for TikTok.
- Gates: hook lint, ending verdict, word-level edge snapping, caption sync against the waveform, the opening-sentence check, the 1080p source gate.
- Render quality: CRF 19, 9 Mbps cap, sources up to 4K.

## Being built next
1. **Cinematic caption style.** Kinetic typography around the speaker:
   - small words flanking the face at eye level
   - key words in large textured type *behind* the speaker (person cut-out via the mediapipe selfie segmenter)
   - a caption palette sampled from each clip's own colours
   Mockup code is in `tools/cinematic.py`. It will ship as an A/B test (full-screen vs cinematic card) via Instagram Trial Reels, and the numbers pick the winner.
2. **TikTok measurement.** Read-only stats connection, so TikTok numbers feed the same reports.
3. **Branded cover template** for every reel's thumbnail, so the grid is instantly recognisable (magazine-cover or quote-card style).
4. **Daily hook trials.** 3-7 hook variants of one clip as Trial Reels; the winner goes to the main feed.
5. **Cinematic cutaways.** Stock footage on concept words (needs a free Pexels key).
