# Setup

Do this in order. Your Claude Code can do most of it; the steps marked **YOU** need a human because they involve logging in or approving access.

## 1. The repository
- **YOU:** create a GitHub account and a new **public** repository named `clip-machine`. It has to be public for free Actions minutes and Pages.
- Copy the `machine/` folder into it as the repo root, commit and push.
- Replace `YOUR_GITHUB_USER` everywhere with your GitHub username. Claude can do this with one search-and-replace.
- Create three GitHub Releases, tagged `media`, `sources` and `state`, all empty.
- Turn on GitHub Pages for the repo, serving the `docs/` folder on `main`.

## 2. Secrets (repo → Settings → Secrets and variables → Actions)
Paste every secret into GitHub yourself. Never paste a key into a chat.

| Secret | What it is | Where it comes from |
|---|---|---|
| `FACTORY_KEY` | Encryption key for stored source videos | `openssl rand -base64 48`; keep a copy at `~/ClipMachine/.factory_key` |
| `IG_ACCESS_TOKEN`, `IG_USER_ID` | Instagram posting + insights | Meta developer app, long-lived token with `instagram_content_publish` + `instagram_manage_insights` |
| `FB_ACCESS_TOKEN`, `FB_PAGE_ID` | Facebook Reels | Same Meta app, Page token |
| `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN` | YouTube Shorts | Google Cloud project, YouTube Data API v3, OAuth |
| `TT_CLIENT_KEY`, `TT_CLIENT_SECRET`, `TT_REFRESH_TOKEN` | TikTok (posts land in your TikTok inbox) | TikTok developer app, Content Posting API |
| `KT_SLOTS` | Daily post times, e.g. `08:00,12:00,16:00,20:00` | Your choice |
| `KT_TZ` | Your time zone, e.g. `America/New_York` | Your choice |
| `KT_CTA_KEYWORDS`, `OFFER_URL` | Comment keywords your auto-reply answers; your offer link | Your offer |
| `KT_PLATFORMS` | Which platforms to post to | e.g. `instagram,facebook,youtube,tiktok` |

A second account uses the same names with an `AR_` prefix (`AR_IG_ACCESS_TOKEN`, `AR_SLOTS`...). Clips in folders starting `AR_` post there; everything else posts to the unprefixed account. Rename the prefix in `engine/poster.py` (`cred_prefix`) if you like.

An `AR_` account never falls back to the unprefixed credentials, so one account can never post to another by accident.

## 3. The clip engine on your own computer (optional)
The cloud factory does everything. A local copy helps you preview clips and write plans.
- Put `pipeline/` in `~/ClipMachine/`.
- Install `ffmpeg`, whisper.cpp at the commit pinned in `machine/factory/setup.sh`, the `ggml-small.en` model, Python 3.9+, `opencv-python`, `numpy` and `pillow`.
- Fonts: Montserrat (free, Google Fonts) goes in `~/ClipMachine/bin/mont_black.ttf`.

## 4. Sources
- Edit `machine/factory/rumble_stock.py` or `pipeline/kt_source_sync.py` to point at **your** source channel.
- Only use content you have the rights to clip.
- YouTube blocks cloud servers, so fetch from a platform that allows it, or let a home computer stock episodes (`kt_source_sync.py` plus the launchd plist).
- Anything under 1080p is refused on purpose.

## 5. First run
1. Trigger the `factory` workflow by hand. It stocks and transcribes.
2. Write one plan with `"test": true` (see `CLAUDE.md`). It renders and checks but never posts. Download the artifact and watch the clips.
3. When they're right, write real plans. The `post` workflow schedules and posts them every 20 minutes.
