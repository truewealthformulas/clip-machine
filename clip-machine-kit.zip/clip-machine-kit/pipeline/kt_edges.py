#!/usr/bin/env python3
"""Start on a sentence, end on a sentence. Nothing else in the pipeline does.

WHY, 3 Sept 2026. the owner: "the starts and ends are at the worst of the video...
its like slightly off, like too mechanically."

Measured, he is right and it is not close. Of 75 clips:

    37 OPEN mid-sentence   - on "into", "and", "change", "you", "about"
    18 END mid-sentence    - on "What you resist," / "So," / "Now."
    28 are clean at both ends

A stranger's decision is made on the first word. "into" is not a first word.

THE CAUSE IS STRUCTURAL. Three tools choose the cut and not one of them knows
where a sentence is:

    kt_sweep  picks a WINDOW of the source
    kt_gold   picks an opener by KEYWORD
    kt_snap   nudges the boundary to the nearest SILENCE

Silence is the closest of the three and still wrong: Kevin pauses mid-thought
for emphasis constantly, and a pause is not a full stop. The transcript knows
exactly where the sentences are and was never consulted.

WHAT THIS DOES. Transcribes a window WIDER than the clip - because the sentence
the clip starts inside of began BEFORE the clip does, and there is no way to
find it from inside. Then it moves `in` back to the start of that sentence and
`out` forward to the end of the one it was cut inside of.

    python3 kt_edges.py                 # show what it would change
    python3 kt_edges.py --apply         # write kt_series.json
    python3 kt_edges.py secret --apply  # one video

It never moves a boundary more than PAD seconds, never shortens a clip, and
leaves a clip alone when no sentence boundary is in reach - a wrong cut is
better than a wrong cut plus ten seconds of the wrong thing.
"""
import json
import os
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~/ClipMachine")
SERIES = os.path.join(HOME, "kt_series.json")
SRC_DIR = os.path.join(HOME, "Content/1_RAW/KT_SOURCE")
FFMPEG = os.path.join(HOME, "bin/ffmpeg")
WHISPER = os.path.join(HOME, "whisper.cpp/build/bin/whisper-cli")
MODEL = os.path.join(HOME, "whisper.cpp/models/ggml-small.en.bin")
CACHE = os.path.join(HOME, "kt_edges.json")

PAD = 34.0          # how far outside the clip to look for a boundary

# THE TWO EDGES DO NOT DESERVE THE SAME BUDGET, 5 Sept 2026.
#
# One number governed both, and it was 9.0 seconds. If the sentence Kevin was
# in the middle of needed more than nine seconds to land, this gave up and left
# the clip cut. Measured after the last pass: 27 of 75 clips still ended
# mid-sentence - "You have a-", "that's like a", "when you look". the owner, having
# said it more times than he should have needed to: "it finishes and you get
# fustrated because it got cut in the middle of a story."
#
# The two edges are not symmetric:
#   START - moving back adds SETUP the viewer did not ask for, and the hook has
#           already promised something. Stay tight.
#   END   - the payoff is the only reason anyone stayed. A clip that runs 20
#           seconds longer to finish the thought is finished; one that stops at
#           9 is broken. On YouTube length costs us nothing (measured: over-120s
#           clips median 1,043 views vs 984 for under-60s), so there is no
#           reason left to cut a thought short.
MAX_MOVE = 9.0       # the START: unchanged, deliberately tight
END_MAX_MOVE = 26.0  # the END: let the sentence land
TMP = f"/tmp/kt_edges_tmp/{os.getpid()}"   # per process: parallel runs shared one file

sys.path.insert(0, HOME)
import kt_words                                          # noqa: E402

ENDERS = (".", "!", "?", '."', '!"', '?"')


def _cache():
    try:
        with open(CACHE) as fh:
            return json.load(fh)
    except (ValueError, OSError):
        return {}


def _save(key, val):
    """Atomic, for the same reason kt_words is: parallel renders read this."""
    c = _cache()
    c[key] = val
    tmp = f"{CACHE}.{os.getpid()}.tmp"
    with open(tmp, "w") as fh:
        json.dump(c, fh)
    os.replace(tmp, CACHE)


def wide_words(src, t0, t1, key):
    """Word timings for a window, in SOURCE seconds. Cached."""
    ck = f"{key}@{t0:.2f}-{t1:.2f}"
    hit = _cache().get(ck)
    if hit is not None:
        return [(a + t0, b + t0, w) for a, b, w in hit]
    os.makedirs(TMP, exist_ok=True)
    wav = os.path.join(TMP, f"e{os.getpid()}.wav")
    subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-ss", f"{t0:.2f}",
                    "-t", f"{t1 - t0:.2f}", "-i", src, "-ar", "16000",
                    "-ac", "1", "-c:a", "pcm_s16le", wav], capture_output=True)
    base = os.path.join(TMP, f"e{os.getpid()}")
    subprocess.run([WHISPER, "-m", MODEL, "-f", wav, "-ml", "1", "-sow",
                    "-osrt", "-of", base], capture_output=True, text=True)
    if not os.path.exists(base + ".srt"):
        return []
    got = kt_words.parse_word_srt(base + ".srt")
    _save(ck, [list(x) for x in got])
    return [(a + t0, b + t0, w) for a, b, w in got]


# A BOUNDARY IS A PAUSE, NOT A FULL STOP. 5 Sept 2026, and this is why every
# previous attempt to fix clip endings failed.
#
# These functions looked for words ending in . ! or ? - and whisper, running in
# word mode (-ml 1 -sow), barely emits punctuation at all. Measured on one clip:
# THREE of ninety-nine words carried any. So sentence_ends() returned almost
# nothing, kt_edges could not find a boundary to move to, and it left the clip
# cut. Raising the movement budget from 9s to 26s changed nothing, because the
# problem was never the budget - there was nothing to move TO.
#
# The signal that IS in the data is silence. Kevin pauses at the end of a
# thought, every time:
#
#     'adversity'   -> gap 0.62s -> "There's"      (new sentence)
#     'greater'     -> gap 1.04s -> 'Benefit'      (new sentence)
#
# So: a gap of GAP seconds or more is a boundary. Punctuation, when whisper
# happens to provide it, still counts - it is simply no longer required.
GAP = 0.50          # silence this long between words ends a thought


def sentence_starts(ws):
    """Source times where a thought BEGINS."""
    out = []
    for i, (a, _b, w) in enumerate(ws):
        if i == 0:
            continue
        prev_w, prev_end = ws[i - 1][2], ws[i - 1][1]
        if not w.strip()[:1].isalnum():
            continue
        if prev_w.strip().endswith(ENDERS) or (a - prev_end) >= GAP:
            out.append(a)
    return out


def sentence_ends(ws):
    """Source times where a thought ENDS."""
    out = []
    for i, (_a, b, w) in enumerate(ws):
        if w.strip().endswith(ENDERS):
            out.append(b)
        elif i + 1 < len(ws) and (ws[i + 1][0] - b) >= GAP:
            out.append(b)
    if ws:
        out.append(ws[-1][1])
    return out


def fix(spec, c):
    src = os.path.join(SRC_DIR, spec["source"])
    if not os.path.exists(src):
        return None
    t_in, t_out = float(c["in"]), float(c["out"])
    ws = wide_words(src, max(0.0, t_in - PAD), t_out + PAD,
                    f"{spec['brand']}/{c['slug']}")
    if not ws:
        return None

    # THE START. Move BACK to the beginning of the sentence the clip is
    # currently sitting inside. Never forward: cutting further in loses the
    # setup, and the hook has already promised something.
    new_in = t_in
    starts = [t for t in sentence_starts(ws) if t <= t_in + 0.35]
    if starts:
        cand = max(starts)
        if 0 < t_in - cand <= MAX_MOVE:
            new_in = max(0.0, cand - 0.18)     # a breath before the first word

    # THE END. Move FORWARD to the end of the sentence being spoken. Never
    # back: trimming to the previous full stop drops the payoff, and the payoff
    # is the only reason the viewer stayed.
    # NEAREST BOUNDARY, IN EITHER DIRECTION - 5 Sept 2026, and this is the third
    # and actual fix.
    #
    # This only ever moved the end FORWARD, on a rule I wrote myself: "never
    # back, trimming to the previous stop drops the payoff." That is true when
    # the clip stops BEFORE its point lands. It is exactly wrong when the clip
    # stops just AFTER it:
    #
    #     'adversity'          52.32   <- 0.86s pause, the thought is complete
    #     "There's another great"      <- the clip ran 0.6s into the NEXT thought
    #
    # The payoff was already in. What broke the ending was three words of the
    # sentence after it. Searching forward from there skipped a perfect boundary
    # sitting half a second behind and dragged the clip on to the next one.
    #
    # So: take whichever real boundary is CLOSEST. Backwards is capped tight
    # (BACK_MAX) because the original worry is still valid - cut back far enough
    # and you really do lose the payoff. Forwards keeps its generous budget.
    BACK_MAX = 3.0
    new_out = t_out
    ends = sentence_ends(ws)
    cands = [t for t in ends
             if -BACK_MAX <= (t - t_out) <= END_MAX_MOVE]
    if cands:
        cand = min(cands, key=lambda t: abs(t - t_out))
        # never cut back so far the clip drops under a workable length
        if cand > t_in + 15.0:
            new_out = cand + 0.35              # let the thought land
    if abs(new_in - t_in) < 0.05 and abs(new_out - t_out) < 0.05:
        return None
    opener = next((w for a, _b, w in ws if a >= new_in - 0.05), "")
    return round(new_in, 2), round(new_out, 2), opener


def main():
    keys = [a for a in sys.argv[1:] if not a.startswith("-")]
    apply = "--apply" in sys.argv
    d = json.load(open(SERIES))
    if not keys:
        keys = [k for k, v in d.items()
                if v["brand"].startswith(("KT_", "MINDSET"))]
    changed = 0
    for k in keys:
        spec = d[k]
        for c in spec["clips"]:
            r = fix(spec, c)
            if not r:
                continue
            ni, no, opener = r
            changed += 1
            print(f"{spec['brand']}/{c['slug'][:34]}")
            print(f"   in  {c['in']:8.2f} -> {ni:8.2f}   ({ni - c['in']:+.2f}s)"
                  f"   opens on: {opener!r}")
            print(f"   out {c['out']:8.2f} -> {no:8.2f}   ({no - c['out']:+.2f}s)"
                  f"   length {no - ni:.0f}s")
            if apply:
                c["in"], c["out"] = ni, no
    if apply and changed:
        shutil.copy(SERIES, SERIES + ".bak")
        tmp = SERIES + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(d, fh, indent=1, ensure_ascii=False)
        os.replace(tmp, SERIES)
        print(f"\n{changed} clip(s) rewritten. Previous kt_series.json kept as "
              f"{os.path.basename(SERIES)}.bak")
        print("The in/out changed, so those clips MUST be re-rendered - and the")
        print("word cache is keyed on the window, so captions regenerate too.")
    else:
        print(f"\n{changed} clip(s) would change. Add --apply to write them.")


if __name__ == "__main__":
    main()
