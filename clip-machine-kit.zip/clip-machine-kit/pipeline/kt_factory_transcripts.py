#!/usr/bin/env python3
"""Fetch and decrypt the cloud factory's transcripts, for writing clip plans.

    python3 kt_factory_transcripts.py        # -> ~/ClipMachine/transcripts/<id>.srt (+ index)
Episodes and transcripts live ENCRYPTED in the kt-machine 'sources' release;
the key is ~/ClipMachine/.factory_key. Prints which episodes still need a plan.
"""
import json, os, subprocess
H = os.path.expanduser("~/ClipMachine"); GH = f"{H}/bin/gh"; R = "YOUR_GITHUB_USER/clip-machine"
run = lambda *a: subprocess.run(list(a), capture_output=True, text=True)
run(GH, "release", "download", "sources", "-R", R, "-p", "sources_index.json", "-D", "/tmp", "--clobber")
idx = json.load(open("/tmp/sources_index.json"))
done = set(json.load(open(f"{H}/kt-machine/factory/plans/_done.json")))
plans = {f[:-5] for f in os.listdir(f"{H}/kt-machine/factory/plans") if f.endswith(".json")}
for vid, e in idx.items():
    if not e.get("transcript"):
        continue
    out = f"{H}/transcripts/{vid}.srt"
    if not os.path.exists(out):
        run(GH, "release", "download", "sources", "-R", R, "-p", e["transcript"], "-D", "/tmp", "--clobber")
        run("openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-pass", f"file:{H}/.factory_key",
            "-in", f"/tmp/{e['transcript']}", "-out", out)
    planned = any(vid in open(f"{H}/kt-machine/factory/plans/{p}.json").read() for p in plans)
    print(f"{vid:14s} {e.get('stops_per_min','?'):>5} stops/min  {'PLANNED' if planned else 'NEEDS A PLAN'}  {e['title'][:60]}")
