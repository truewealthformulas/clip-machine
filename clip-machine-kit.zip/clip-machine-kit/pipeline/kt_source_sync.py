#!/usr/bin/env python3
"""Keep the cloud clip factory stocked with HD episodes of Kevin's show.

WHY THIS EXISTS. 19 Sept 2026. The cloud cannot download from YouTube: YouTube
answers GitHub's servers with "Sign in to confirm you're not a bot". the owner's home
connection is not blocked. So the Mac does the one thing only it can do - fetch
the episode - and the cloud does everything else with the Mac shut.

Runs from launchd every 2 hours (com.owner.sourcesync). Does nothing unless the
Mac is on AC power. Newest episodes first. Every file is ENCRYPTED before upload:
kt-machine is a public repository, and a public copy of Kevin's full shows is
exactly what the GIN anti-piracy team hunts - a takedown would take the posting
machine down with it. The key lives in ~/ClipMachine/.factory_key and the FACTORY_KEY
secret; nobody can play what is in the release.

    python3 kt_source_sync.py          # normal run (launchd)
    python3 kt_source_sync.py --dry    # list what it would fetch, change nothing
    python3 kt_source_sync.py --force  # ignore the AC-power guard
"""
import datetime
import json
import os
import re
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~/ClipMachine")
BIN = os.path.join(HOME, "bin")
YTDLP = os.path.join(BIN, "yt-dlp_macos")
FF = os.path.join(BIN, "ffmpeg")
GH = os.path.join(BIN, "gh")
KEY = os.path.join(HOME, ".factory_key")
REPO = "YOUR_GITHUB_USER/clip-machine"
TAG = "sources"
CHANNEL = "https://www.youtube.com/channel/YOUR_SOURCE_CHANNEL_ID/videos"
CACHE = os.path.join(HOME, "work", "source_cache")
LOCAL_LIB = os.path.join(HOME, "Content", "1_RAW", "KT_SOURCE")
LOG = os.path.join(HOME, "logs", "source_sync.log")
LOCK = "/tmp/kt_source_sync.lock"
STOCK = 12            # unplanned episodes to keep in the cloud
PER_RUN = 2           # downloads per run, so it never hogs the connection
MIN_SECS = 20 * 60    # full episodes only
DRY = "--dry" in sys.argv


def log(msg):
    line = f"{datetime.datetime.now():%Y-%m-%d %H:%M} {msg}"
    print(line)
    if not DRY:
        with open(LOG, "a") as fh:
            fh.write(line + "\n")


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def on_ac_power():
    return "AC Power" in run(["pmset", "-g", "batt"]).stdout


def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def index_get():
    """The release's own list of what it holds. Absent on the first run."""
    tmp = os.path.join(CACHE, "sources_index.json")
    r = run([GH, "release", "download", TAG, "-R", REPO, "-p", "sources_index.json",
             "-O", tmp, "--clobber"])
    if r.returncode:
        return {}
    return json.load(open(tmp))


def index_put(idx):
    tmp = os.path.join(CACHE, "sources_index.json")
    json.dump(idx, open(tmp, "w"), indent=1)
    r = run([GH, "release", "upload", TAG, tmp, "--clobber", "-R", REPO])
    if r.returncode:
        raise SystemExit(f"index upload failed: {r.stderr[-200:]}")


def excluded_titles():
    """Episodes already clipped for the owner, and every episode fenced to brand-2 owner."""
    series = json.load(open(os.path.join(HOME, "kt_series.json")))
    return {norm(os.path.splitext(s.get("source", ""))[0]) for s in series.values()}


def height(path):
    m = re.search(r"Video:.*?(\d{3,4})x(\d{3,4})", run([FF, "-i", path]).stderr)
    return int(m[2]) if m else 0


def main():
    os.makedirs(CACHE, exist_ok=True)
    if not DRY and "--force" not in sys.argv and not on_ac_power():
        return                                    # silent: on battery
    if os.path.exists(LOCK):
        try:
            os.kill(int(open(LOCK).read()), 0)
            return                                # another run is working
        except (OSError, ValueError):
            pass
    open(LOCK, "w").write(str(os.getpid()))
    try:
        idx = index_get()
        stocked = [k for k, v in idx.items() if v.get("status") == "stocked"]
        if len(stocked) >= STOCK:
            log(f"stock full ({len(stocked)} unplanned episodes) - nothing to do")
            return
        listing = run([YTDLP, "--no-warnings", "--flat-playlist", "--playlist-end", "80",
                       "--print", "%(id)s\t%(duration)s\t%(title)s", CHANNEL]).stdout
        skip = excluded_titles()
        todo = []
        for line in listing.splitlines():
            vid, dur, title = (line.split("\t") + ["", ""])[:3]
            if vid in idx or not dur or dur == "NA" or float(dur) < MIN_SECS:
                continue
            if any(norm(title)[:40] and norm(title)[:40] in t for t in skip):
                continue
            todo.append((vid, float(dur), title))
        want = min(PER_RUN, STOCK - len(stocked))
        log(f"{len(stocked)} stocked, {len(todo)} new full episodes on the channel, "
            f"fetching {min(want, len(todo))}")
        for vid, dur, title in todo[:want]:
            log(f"  {vid}  {dur/60:.0f} min  {title[:70]}")
            if DRY:
                continue
            mp4 = os.path.join(CACHE, f"{vid}.mp4")
            r = run([YTDLP, "--no-warnings", "-q", "-N", "8", "--ffmpeg-location", BIN,
                     "-f", "bv*[height=1080][protocol*=m3u8]+ba/bv*[height>=1080]+ba",
                     "--merge-output-format", "mp4", "-o", mp4,
                     f"https://www.youtube.com/watch?v={vid}"])
            h = height(mp4) if os.path.exists(mp4) else 0
            if h < 1080:
                log(f"    REJECTED: {h}p (download error: {r.stderr.strip()[-120:]})")
                idx[vid] = {"title": title, "status": "rejected", "height": h}
                index_put(idx)
                continue
            enc = mp4 + ".enc"
            e = run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt",
                     "-pass", f"file:{KEY}", "-in", mp4, "-out", enc])
            if e.returncode:
                log(f"    ENCRYPT FAILED: {e.stderr[-120:]}")
                continue
            u = run([GH, "release", "upload", TAG, enc, "--clobber", "-R", REPO])
            if u.returncode:
                log(f"    UPLOAD FAILED: {u.stderr[-160:]}")
                os.remove(enc)
                continue
            # READ IT BACK: a 0 exit code is not proof the asset is whole.
            assets = json.loads(run([GH, "release", "view", TAG, "-R", REPO,
                                     "--json", "assets"]).stdout)["assets"]
            size = next((a["size"] for a in assets if a["name"] == f"{vid}.mp4.enc"), 0)
            if size != os.path.getsize(enc):
                log(f"    SIZE MISMATCH after upload ({size} vs {os.path.getsize(enc)})")
                continue
            idx[vid] = {"title": title, "duration": dur, "height": h, "status": "stocked",
                        "uploaded": f"{datetime.datetime.now():%Y-%m-%dT%H:%M}"}
            index_put(idx)
            os.remove(enc)
            # Keep an HD copy on the Mac for local sessions, disk permitting.
            # Named by video id, exactly as the cloud names it, so one clip plan
            # ("source": "<id>.mp4") works in both places.
            if shutil.disk_usage(HOME).free > 8e9:
                shutil.move(mp4, os.path.join(LOCAL_LIB, f"{vid}.mp4"))
            else:
                os.remove(mp4)
            log(f"    STOCKED {h}p, {size/1e6:.0f} MB encrypted")
    finally:
        os.remove(LOCK)


if __name__ == "__main__":
    main()
