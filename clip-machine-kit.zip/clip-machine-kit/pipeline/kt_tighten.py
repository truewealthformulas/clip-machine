#!/usr/bin/env python3
"""A tightened clip, built in the RIGHT ORDER: cut the picture, then caption it.

WHY THIS EXISTS. 16 Sept 2026, the YWIYC royalties story. the owner wanted it under
two minutes ("more than 2 minutes its too much"). The first tightened version was
made by cutting pieces out of the FINISHED render - framing, captions and hook
already burned in. Every join was audio-clean. The picture was not:

    first frame after join 4:   caption "CONTACT DETAILS."  (a cut sentence)
    last frames before join 7:  caption "HE SOLD"           (a cut sentence)

Captions burned onto the full three minutes belong to the full three minutes.
At a cut, the caption on screen is the one for the sentence that was just
deleted. No audio check can see that, because it is only in the pixels.

So the order is reversed here, and it is the only order that is correct:

  1. Each kept stretch is framed ON ITS OWN - its own camera analysis, its own
     crop - and encoded with no text at all.
  2. The clean pieces are joined, with a 20ms audio fade at each seam so speech
     does not click, and a short fade after the last line.
  3. Word timings for each piece are shifted onto the EDITED timeline, caption
     bursts are built per piece so no burst can straddle a cut, and the hook
     and captions are burned onto the finished edit.

A caption can therefore only ever show words that are actually in the clip.

The KEEP list is chosen by a person reading the story. Tangents are an
editorial call, not a measurement.

    python3 kt_tighten.py <series> <slug> keep.json OUT.mp4
      keep.json = [[src_in, src_out, "note"], ...]  in SOURCE seconds
"""
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.expanduser("~/ClipMachine"))
import kt_render as R                                          # noqa: E402
import kt_words                                                # noqa: E402

HOME = os.path.expanduser("~/ClipMachine")
EDGE = 0.02
FINAL = 0.20


def slice_shots(full, origin, a, b):
    """The whole-story shot map, cut down to one piece and moved to its clock.

    NOT a fresh analysis per piece, and that was measured, not assumed. Piece 1
    of the YWIYC story (618.27-646.44) analysed on its own came back as ONE
    camera setup. The whole story analysed once shows the camera going wide 27s
    in - inside piece 1's last second. A shot that short is merged away when the
    window is small, so a per-piece analysis would crop the wide angle as if it
    were the close-up. The long analysis sees shots the short one cannot.
    """
    off, d = a - origin, b - a
    out = []
    for sh in full:
        s0, s1 = sh["start"] - off, sh["end"] - off
        if s1 <= 0 or s0 >= d:
            continue
        out.append(dict(sh, start=max(0.0, s0), end=min(d, s1)))
    return out or None


HOLD = 0.7      # the last frame held after the final word, fading out


def encode_piece(src, a, b, cx, zoom, full, origin, i, n, dest, punch=1.0):
    shots = slice_shots(full, origin, a, b) if full else None
    geo = R.fill_crop(src, cx, zoom, shots)
    d = b - a
    af = []
    if i > 0:
        af.append(f"afade=t=in:st=0:d={EDGE}")
    # A PUNCH-IN HIDES A JUMP CUT. 16 Sept 2026, the owner: "its very hard cut every
    # few seconds... the viewer will notice easily and get annoyed." When the
    # camera angle is the SAME either side of a cut, the picture jumps in place
    # and it reads as a glitch. Every talking-head editor answers that the same
    # way: the next piece is slightly closer, so the cut reads as deliberate.
    # Anchored above centre so his face stays in frame.
    punch_vf = (f",crop=iw/{punch}:ih/{punch}:(iw-iw/{punch})/2:(ih-ih/{punch})*0.30,"
                f"scale=1080:1920" if punch > 1.001 else "")
    if i < n - 1:
        af.append(f"afade=t=out:st={max(0.0, d - EDGE):.3f}:d={EDGE}")
        vchain = geo + punch_vf
    else:
        # A SMOOTH ENDING. the owner: "make the ending also smooth." The last piece
        # ends in the real pause after the final word; its last frame is then
        # held for HOLD seconds while picture and sound fade out together, so
        # the clip settles instead of stopping.
        af.append(f"apad=pad_dur={HOLD}")
        af.append(f"afade=t=out:st={max(0.0, d - 0.15):.3f}:d={HOLD + 0.15:.2f}")
        vchain = (geo + punch_vf + f",tpad=stop_mode=clone:stop_duration={HOLD},"
                  f"fade=t=out:st={max(0.0, d - 0.05):.3f}:d={HOLD + 0.05:.2f}")
    use_fc = zoom < 0.999          # fill_crop returns a filtergraph when zoomed out
    cmd = [R.FFMPEG, "-y", "-loglevel", "error", "-ss", f"{a:.3f}", "-t", f"{d:.3f}",
           "-i", src]
    if use_fc:
        cmd += ["-filter_complex", vchain]
    else:
        cmd += ["-vf", vchain]
    cmd += ["-af", ",".join(af), "-c:v", "libx264", "-preset", "medium", "-crf", "17",
            "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "160k",
            "-ar", "48000", dest]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"piece {i} failed: {r.stderr[-400:]}")
    return len(shots) if shots else 1


def length(path):
    import re
    e = subprocess.run([R.FFMPEG, "-hide_banner", "-i", path],
                       capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", e)
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def main():
    if len(sys.argv) < 5:
        raise SystemExit(__doc__)
    key, slug, keep_path, out = sys.argv[1:5]
    spec = json.load(open(os.path.join(HOME, "kt_series.json")))[key]
    clip = next(c for c in spec["clips"] if c["slug"] == slug)
    src = os.path.join(R.SRC_DIR, spec["source"])
    cx, zoom = float(spec.get("cx", 0.5)), float(spec.get("zoom", 1.0))
    keep = [(float(a), float(b)) for a, b, *_ in json.load(open(keep_path))]
    origin, end = float(clip["in"]), float(clip["out"])
    whole = R.shots_for(src, origin, end, slug)
    full = (whole or {}).get("segments") or []
    if not full:
        sys.stderr.write("  WARNING: no shot map for the whole story - fixed crop\n")
    if keep[0][0] < origin - 0.5 or keep[-1][1] > end + 0.5:
        raise SystemExit(f"keep list runs outside the analysed span {origin}-{end}")
    work = os.path.abspath(out) + ".work"
    os.makedirs(work, exist_ok=True)

    # 1. clean, framed pieces - and their REAL lengths, which are what the
    #    edited timeline is made of (re-encoding snaps each to whole frames)
    # Which pieces get the punch-in: toggle it at every cut where the camera
    # angle does NOT change; a real camera change is already a clean cut.
    zooms, cur = [], 1.0
    for i, (a, b) in enumerate(keep):
        if i > 0:
            ps = slice_shots(full, origin, keep[i - 1][0], keep[i - 1][1]) or []
            ts = slice_shots(full, origin, a, b) or []
            same = bool(ps and ts and abs(ps[-1]["cx"] - ts[0]["cx"]) < 0.06)
            cur = (1.09 if cur == 1.0 else 1.0) if same else 1.0
        zooms.append(cur)
    pieces, starts, t = [], [], 0.0
    for i, (a, b) in enumerate(keep):
        p = os.path.join(work, f"{i:02d}.mp4")
        # --reuse: a caption, hook or photo change only touches the final pass,
        # so the framed pieces - the slow part, cut from a 4K source - are kept.
        if "--reuse" in sys.argv and os.path.exists(p) and os.path.getsize(p) > 0:
            ns = 0
        else:
            ns = encode_piece(src, a, b, cx, zoom, full, origin, i, len(keep), p, zooms[i])
        L = length(p)
        pieces.append(p)
        starts.append(t)
        print(f"  piece {i + 1:2d}  {a:7.2f}-{b:7.2f}  {L:5.2f}s  {ns} camera setup(s)  zoom {zooms[i]:.2f}")
        t += L
    total = t

    # 2. join the clean pieces
    lst = os.path.join(work, "list.txt")
    open(lst, "w").write("".join(f"file '{p}'\n" for p in pieces))
    joined = os.path.join(work, "joined.mp4")
    r = subprocess.run([R.FFMPEG, "-y", "-loglevel", "error", "-f", "concat", "-safe",
                        "0", "-i", lst, "-c", "copy", joined], capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"join failed: {r.stderr[-300:]}")

    # 3. captions on the EDITED timeline, built per piece so none straddles a cut
    fix = {k.lower(): v for k, v in (clip.get("fix") or {}).items()}
    bursts = []
    for i, (a, b) in enumerate(keep):
        ws = kt_words.words_for(src, a, b, f"{spec['brand']}/{slug}-p{i:02d}")
        ws = [(x, y, fix.get(w.lower().strip(), w)) for x, y, w in ws]
        # NO HALF-WORDS AT A PIECE EDGE. A piece ending a hair into the next
        # sentence gave whisper a syllable to transcribe, and "HE'S THE..." went
        # on screen for a sentence that was cut. Drop anything whisper marked as
        # trailing off, and anything starting in the piece's last 0.15s.
        span = b - a
        ws = [(x, y, w) for x, y, w in ws
              if not w.rstrip().endswith(("...", "--", "\u2014", "\u2026"))
              and x < span - 0.15]
        # NOTHING AFTER THE LAST FULL STOP. Every piece is cut at a sentence end
        # and checked by ear, so words after a piece's final full stop can only be
        # a sliver of the next, deleted sentence that whisper turned into a word -
        # "ED BECKLEY." then "HE'S".
        #
        # ONLY A SLIVER. The first version dropped EVERYTHING after the last
        # full stop, and piece 1 of the YWIYC story ends on a comma ("...which I
        # think is closed now,") - so five seconds went out with no captions at
        # all, "Carnegie Deli" included. A deleted-sentence fragment is a word or
        # two in the piece's last moment; a real clause is seconds long.
        last = max((k for k, (_x, _y, w) in enumerate(ws)
                    if w.rstrip().endswith((".", "!", "?"))), default=None)
        if last is not None and last + 1 < len(ws):
            tail = ws[last + 1:]
            if len(tail) <= 2 and tail[0][0] > span - 0.7:
                ws = ws[:last + 1]
        # A PIECE NEVER ENDS ON A CONNECTIVE. Whisper gave a scrap of the next
        # sentence its own full stop - "SO." - so the rule above saw a complete
        # sentence and kept it, and it went on screen before "IT WORKS." Pieces
        # are cut at sentence ends, so a trailing "so", "and", "but" can only be
        # a sliver of what was deleted.
        while ws and ws[-1][2].lower().strip(".,!?;:\"'") in (
                "so", "and", "but", "now", "then", "well", "because", "or", "um", "uh"):
            ws = ws[:-1]
        ps = R.phrases_from_words(ws) if ws else []
        # never let the last burst of a piece hold past its own seam
        seg_end = starts[i + 1] if i + 1 < len(starts) else total
        for x, y, txt in ps:
            x2, y2 = starts[i] + x, min(starts[i] + y, seg_end - 0.02)
            if y2 > x2:
                bursts.append((x2, y2, txt))
    caps = R.caption_chain(bursts)
    json.dump([[a, b, t] for a, b, t in bursts],
              open(os.path.splitext(out)[0] + "__caps.json", "w"))

    hlines = [l for l in clip["hook"] if l.strip()]
    cpath = os.path.join(R.CARDS, f"{slug}-tight.png")
    _, _cw, _ch = R.hook_card(hlines, cpath)
    cy_px, _soft, fit = R.card_y(src, keep[0][0], _ch)
    card = R.hook_card(hlines, cpath, max_h=fit)[0] if fit else cpath

    # PHOTOS, UNDER THE CAPTIONS. the owner, 16 Sept 2026: "you could also edit the
    # video putting pics so people get even more hooked." A photo is placed by
    # the SOURCE second its word is spoken and mapped onto the edited timeline,
    # so it survives any re-cut. Slow push-in so it is not a dead still, a short
    # alpha fade either side, and it sits below the captions so they stay
    # readable. Only images we have rights to: GIN's own product photography,
    # or freely licensed ones.
    broll_inputs, broll_chain, base = [], [], "0:v"
    for n, b in enumerate(clip.get("broll") or []):
        at = float(b["src_at"])
        piece = next((k for k, (ka, kb) in enumerate(keep) if ka <= at < kb), None)
        if piece is None:
            sys.stderr.write(f"  photo at {at} is in a cut stretch - skipped\n")
            continue
        t0 = starts[piece] + (at - keep[piece][0])
        d = float(b.get("dur", 2.2))
        # "to_cut": run exactly to the end of this piece. Re-encoding snaps each
        # piece to whole frames, so a duration measured in SOURCE seconds ended
        # the book 0.13s before the cut to "It works."
        if b.get("to_cut") and piece + 1 < len(starts):
            d = starts[piece + 1] - t0
        img = os.path.expanduser(b["image"])
        still = os.path.join(work, f"broll{n}.mp4")
        frames = int(d * 30)
        r = subprocess.run([R.FFMPEG, "-y", "-loglevel", "error", "-loop", "1", "-i", img,
            "-vf", ("scale=1296:2304:force_original_aspect_ratio=increase,crop=1296:2304,"
                    f"zoompan=z='min(zoom+0.0009,1.07)':d={frames}:"
                    "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps=30,"
                    "format=yuv420p"),
            "-t", f"{d:.2f}", "-c:v", "libx264", "-preset", "medium", "-crf", "18", still],
            capture_output=True, text=True)
        if r.returncode:
            sys.stderr.write(f"  photo {img} failed: {r.stderr[-200:]}\n")
            continue
        idx = 2 + len(broll_inputs) // 4
        broll_inputs += ["-itsoffset", f"{t0:.3f}", "-i", still]
        fade = min(0.2, d / 4)
        broll_chain.append(
            f"[{idx}:v]format=rgba,fade=t=in:st={t0:.3f}:d={fade:.2f}:alpha=1,"
            f"fade=t=out:st={t0 + d - fade:.3f}:d={fade:.2f}:alpha=1[br{n}];"
            f"[{base}][br{n}]overlay=eof_action=pass[pv{n}];")
        base = f"pv{n}"
        print(f"  photo {n + 1}: {os.path.basename(img)} at {t0:.2f}s for {d:.1f}s")

    fc = ("".join(broll_chain) +
          f"[{base}]{','.join(caps) if caps else 'null'}[bg];"
          f"[1:v]format=rgba,fade=out:st={R.HOOK_SECS - 0.3:.2f}:d=0.3:alpha=1[hk];"
          f"[bg][hk]overlay=x=(W-w)/2:y={cy_px}:enable='lt(t,{R.HOOK_SECS})'[v]")
    r = subprocess.run([R.FFMPEG, "-y", "-loglevel", "error", "-i", joined,
                        "-loop", "1", "-framerate", "30", "-t", f"{R.HOOK_SECS:.2f}",
                        "-i", card, *broll_inputs, "-filter_complex", fc, "-map", "[v]", "-map", "0:a",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                        "-maxrate", "3500k", "-bufsize", "7000k", "-pix_fmt", "yuv420p",
                        "-c:a", "copy", "-movflags", "+faststart", out],
                       capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"caption burn failed: {r.stderr[-400:]}")
    json.dump({"keep": keep, "starts": starts, "total": total},
              open(os.path.join(work, "timeline.json"), "w"), indent=1)
    print(f"\n{len(keep)} pieces, {len(bursts)} caption bursts, {total:.1f}s -> {out}")


if __name__ == "__main__":
    main()
