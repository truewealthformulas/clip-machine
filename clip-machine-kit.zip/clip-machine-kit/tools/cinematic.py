"""'KT Cinematic' mockups from the owner's three reference reels (22 Sept 2026).

1. flanking: small clean words either side of Kevin's face at eye level (ref 3)
2. key word: a huge textured word BEHIND Kevin, paired with a script word (refs 1-2)
3. card: the same beats on a 16:9 card floating on black, as in all three refs
"""
import os, cv2
import os
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mpt
from mediapipe.tasks.python import vision
from PIL import Image, ImageDraw, ImageFont, ImageFilter

K = os.path.expanduser("~/ClipMachine/bin/")
MB, MSEMI = K + "mont_black.ttf", K + "fonts/MontserratVar.ttf"
PLAYI, CIN = K + "fonts/PlayfairItalic.ttf", K + "fonts/Cinzel.ttf"
W, H = 1080, 1920
SEG = vision.ImageSegmenter.create_from_options(vision.ImageSegmenterOptions(
    base_options=mpt.BaseOptions(model_asset_path=K + "selfie_segmenter.tflite"), output_confidence_masks=True))
DET = lambda w, h: cv2.FaceDetectorYN_create(K + "yunet.onnx", "", (w, h), 0.6, 0.3, 5000)
full = cv2.imread("src.png")[:, :, ::-1]


def font(path, size, wght=None):
    f = ImageFont.truetype(path, size)
    if wght:
        try: f.set_variation_by_axes([wght])
        except Exception: pass
    return f


def person(rgb):
    r = SEG.segment(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
    m = np.squeeze(r.confidence_masks[0].numpy_view()).astype(np.float32)
    return np.asarray(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.5)), np.float32) / 255


def face(rgb):
    h, w = rgb.shape[:2]; ok, f = DET(w, h).detect(np.ascontiguousarray(rgb[:, :, ::-1]))
    b = max(f, key=lambda r: r[2] * r[3]); return [float(v) for v in b[:4]], (b[5] + b[7]) / 2


def hook(d, y0=470):
    f = font(MB, 74); bw, bh = 900, 250; x0 = (W - bw) // 2
    d.rounded_rectangle((x0, y0, x0 + bw, y0 + bh), 28, fill=(18, 18, 18, 235))
    for i, l in enumerate(["WHY BALANCE KEEPS", "YOU BROKE"]):
        tw = d.textlength(l, font=f); d.text(((W - tw) / 2, y0 + 38 + i * 92), l, font=f, fill="white")
    d.rounded_rectangle((x0 + 40, y0 + bh - 22, x0 + 190, y0 + bh - 12), 4, fill=(245, 197, 24))


def soft_text(im, xy, text, f, fill=(250, 248, 242), anchor="la", shadow=190):
    sh = Image.new("RGBA", im.size); ImageDraw.Draw(sh).text((xy[0] + 2, xy[1] + 4), text, font=f, fill=(0, 0, 0, shadow), anchor=anchor)
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6))); ImageDraw.Draw(im).text(xy, text, font=f, fill=fill, anchor=anchor)


def gold_behind(im, rgb_bg, pmask, text, f, center, box_top):
    """A knife-edged gold-leaf word placed BEHIND the person (the person mask cuts it)."""
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).text(center, text, font=f, fill=255, anchor="ms")
    M = np.asarray(m, np.float32) / 255
    ys = np.clip((np.arange(im.size[1])[:, None] - box_top) / (f.size * 0.9), 0, 1).repeat(im.size[0], 1)
    G = np.zeros(M.shape + (3,), np.float32)
    for k, st in enumerate(zip((252, 226, 150), (205, 158, 60), (160, 115, 30), (238, 200, 115))):
        G[..., k] = np.interp(ys, [0, 0.45, 0.6, 1], st)
    gy, gx = np.gradient(np.asarray(m.filter(ImageFilter.GaussianBlur(2.5)), np.float32) / 255)
    s = -(gx + gy); s /= (np.abs(s).max() + 1e-6)
    G = np.clip(G + np.clip(s, 0, 1)[..., None] * 230 - np.clip(-s, 0, 1)[..., None] * 110, 0, 255)
    vis = M * (1 - pmask)                         # the person stands in front of the word
    base = np.asarray(im.convert("RGB"), np.float32)
    shadow = np.asarray(Image.fromarray((np.roll(np.roll(M, 10, 0), 6, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(12)), np.float32) / 255 * (1 - pmask)
    base = base * (1 - shadow[..., None] * 0.55)
    out = base * (1 - vis[..., None]) + G * vis[..., None]
    return Image.fromarray(out.astype(np.uint8)).convert("RGBA")


def place_behind(pmask, text, sizes, y_lo, y_hi, want=(0.15, 0.35)):
    """Where to put a word BEHIND the person so it keeps depth but stays readable:
    the size/height where the person covers 15-35% of it (closest to 25%)."""
    best = None
    for sz in sizes:
        f = font(MB, sz)
        for y in range(int(y_lo), int(y_hi), 20):
            m = Image.new("L", (pmask.shape[1], pmask.shape[0]), 0)
            ImageDraw.Draw(m).text((pmask.shape[1] // 2, y), text, font=f, fill=255, anchor="ms")
            M = np.asarray(m, np.float32) / 255
            if M.sum() == 0:
                continue
            cov = float((M * pmask).sum() / M.sum())
            score = abs(cov - 0.25) - (0.001 * sz)          # prefer bigger when equally good
            if want[0] <= cov <= want[1] and (best is None or score < best[0]):
                best = (score, sz, y, cov)
    return best


# --- full-bleed: crop centred on Kevin's face (as the renderer does) ------------------
(fx, fy, fw, fh), _ = face(full)
cw = int(full.shape[0] * 9 / 16); cx0 = int(fx + fw / 2 - cw / 2)
bleed = cv2.resize(np.ascontiguousarray(full[:, cx0:cx0 + cw]), (W, H), interpolation=cv2.INTER_LANCZOS4)
(bx, by, bw_, bh_), eye = face(bleed); P = person(bleed)

# 1 flanking words at eye level
im = Image.fromarray(bleed).convert("RGBA"); d = ImageDraw.Draw(im)
f = font(MSEMI, 50, 600)
soft_text(im, (bx - 36, eye), "it's easy", f, anchor="rm"); soft_text(im, (bx + bw_ + 36, eye), "to make", f, anchor="lm")
hook(ImageDraw.Draw(im), y0=1300); im.convert("RGB").save("cine_1_flank.jpg", quality=94)

# 2 key word behind Kevin, script word above it
im = Image.fromarray(bleed).convert("RGBA")
b = place_behind(P, "MONEY", (320, 280, 240, 200), 560, 1350) or (0, 260, 700, 0)
print("full-bleed MONEY: size", b[1], "baseline", b[2], "covered", round(b[3], 2))
big = font(MB, b[1]); top = b[2] - int(b[1] * 0.75)
im = gold_behind(im, bleed, P, "MONEY", big, (W // 2, b[2]), top)
soft_text(im, (W // 2, top - 14), "to make", font(PLAYI, 96, 600), anchor="ms")
hook(ImageDraw.Draw(im), y0=1450); im.convert("RGB").save("cine_2_behind.jpg", quality=94)

# 3 card: the 16:9 shot on black, words flanking the face inside the card, key word behind
card_w = W; card_h = int(full.shape[0] * W / full.shape[1]); cy0 = (H - card_h) // 2 - 40
card = cv2.resize(full, (card_w, card_h), interpolation=cv2.INTER_AREA)
Pc = person(card); (qx, qy, qw, qh), qeye = face(card)
canvas = np.zeros((H, W, 3), np.uint8); canvas[cy0:cy0 + card_h] = card
Pfull = np.zeros((H, W), np.float32); Pfull[cy0:cy0 + card_h] = Pc
im = Image.fromarray(canvas).convert("RGBA")
bc = place_behind(Pfull, "MONEY", (260, 230, 200, 170), cy0 + 120, cy0 + card_h - 10) or (0, 200, cy0 + card_h - 40, 0)
print("card MONEY: size", bc[1], "baseline", bc[2], "covered", round(bc[3], 2))
im = gold_behind(im, canvas, Pfull, "MONEY", font(MB, bc[1]), (W // 2, bc[2]), bc[2] - int(bc[1] * 0.75))
fs = font(MSEMI, 38, 600)
soft_text(im, (qx - 24, cy0 + qeye), "it's easy", fs, anchor="rm"); soft_text(im, (qx + qw + 24, cy0 + qeye), "to make", fs, anchor="lm")
d = ImageDraw.Draw(im); hook(d, y0=cy0 - 330)
d.text((W // 2, cy0 + card_h + 120), "KT", font=font(CIN, 44, 600), fill=(200, 170, 90), anchor="ms")
im.convert("RGB").save("cine_3_card.jpg", quality=94)

sheet = Image.new("RGB", (540 * 3 + 40, 960 + 70), (14, 14, 14)); sd = ImageDraw.Draw(sheet)
lf = font(K + "mont_eb.ttf", 26)
for k, (fn, name) in enumerate([("cine_1_flank.jpg", "1 Flanking words at eye level"), ("cine_2_behind.jpg", "2 Gold word behind Kevin"), ("cine_3_card.jpg", "3 Cinematic card on black")]):
    sheet.paste(Image.open(fn).resize((540, 960), Image.LANCZOS), (k * 560, 0)); sd.text((k * 560 + 12, 975), name, font=lf, fill=(235, 235, 235))
sheet.save("KT_CINEMATIC.jpg", quality=92); print("done")
