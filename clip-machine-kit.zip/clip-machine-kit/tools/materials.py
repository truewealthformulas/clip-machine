"""Cinzel capitals in precious MATERIALS, rendered at 2x for knife-sharp HD edges.

22 Sept 2026, the owner: likes #3's letters (Cinzel) but "it's about the texture, it has
to feel different, professional, unique, privileged ... like a blade glass, very HD".
Cheap = blur and glow. Expensive = crisp edges, fine highlights, real texture.
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

S = 2                                   # supersample: render big, shrink = HD edges
W, H = 1080, 1920
CINZEL = "~/ClipMachine/bin/fonts/Cinzel.ttf"
MB = "~/ClipMachine/bin/mont_black.ttf"
src = Image.open("src.png"); w, h = src.size; cw = int(h * 9 / 16); x = (w - cw) // 2 - 170
BASE = src.crop((x, 0, x + cw, h)).resize((W, H), Image.LANCZOS).convert("RGB")
Y0, Y1 = 1060, 1440                    # caption band (1x coords)
rng = np.random.default_rng(7)


def hook(im):
    d = ImageDraw.Draw(im, "RGBA"); f = ImageFont.truetype(MB, 74); bw, bh = 900, 250; x0, y0 = (W - bw) // 2, 470
    d.rounded_rectangle((x0, y0, x0 + bw, y0 + bh), 28, fill=(18, 18, 18, 235))
    for i, l in enumerate(["WHY BALANCE KEEPS", "YOU BROKE"]):
        tw = d.textlength(l, font=f); d.text(((W - tw) / 2, y0 + 38 + i * 92), l, font=f, fill="white")
    d.rounded_rectangle((x0 + 40, y0 + bh - 22, x0 + 190, y0 + bh - 12), 4, fill=(245, 197, 24))


BW, BH = W * S, (Y1 - Y0) * S
f = ImageFont.truetype(CINZEL, 84 * S)
try:
    f.set_variation_by_axes([700])
except Exception:
    pass
lines = ["IT'S EASY TO", "MAKE MONEY"]
m = Image.new("L", (BW, BH), 0); d = ImageDraw.Draw(m)
track = 6 * S
for li, t in enumerate(lines):
    tot = sum(f.getlength(c) + track for c in t) - track; cx = (BW - tot) / 2; yy = 40 * S + li * int(f.size * 1.18)
    for c in t:
        d.text((cx, yy), c, font=f, fill=255); cx += f.getlength(c) + track
M = np.asarray(m, np.float32) / 255
ys = np.linspace(0, 1, BH)[:, None].repeat(BW, 1)


def g(a, r):
    return np.asarray(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r)), np.float32)


def edges(r=1.6):
    """Knife-sharp bevel: bright top-left facet, dark bottom-right facet."""
    gy, gx = np.gradient(g(M * 255, r * S) / 255)
    s = -(gx + gy); s /= (np.abs(s).max() + 1e-6)
    return np.clip(s, 0, 1), np.clip(-s, 0, 1)


HI, LO = edges()
RIM = np.clip(np.asarray(Image.fromarray((M * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(2 * S + 1)), np.float32) / 255 - M, 0, 1)


def noise(scale_x, scale_y, blur=0):
    n = rng.random((max(2, BH // scale_y), max(2, BW // scale_x))).astype(np.float32)
    n = np.asarray(Image.fromarray((n * 255).astype(np.uint8)).resize((BW, BH), Image.BICUBIC), np.float32) / 255
    return g(n * 255, blur) / 255 if blur else n


def vgrad(stops):
    out = np.zeros((BH, BW, 3), np.float32)
    for c in range(3):
        out[..., c] = np.interp(ys, [s[0] for s in stops], [s[1][c] for s in stops])
    return out


def finish(fill, rim=None, hi=1.0, lo=1.0, alpha=1.0, spec=(255, 255, 255)):
    bg = np.asarray(BASE.crop((0, Y0, W, Y1)).resize((BW, BH), Image.LANCZOS), np.float32)
    sh = g(np.roll(np.roll(M, 7 * S, 0), 4 * S, 1) * 255, 7 * S) / 255
    out = bg * (1 - sh[..., None] * 0.6)
    F = fill + HI[..., None] * np.array(spec) * 0.9 * hi - LO[..., None] * 120 * lo
    F = np.clip(F, 0, 255)
    out = out * (1 - M[..., None] * alpha) + F * M[..., None] * alpha
    if rim is not None:
        out = out * (1 - RIM[..., None]) + np.array(rim, np.float32) * RIM[..., None]
    band = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).resize((W, Y1 - Y0), Image.LANCZOS)
    im = BASE.copy(); im.paste(band, (0, Y0)); hook(im); return im


def crystal(tint, deep):
    bg = np.asarray(BASE.crop((0, Y0, W, Y1)).resize((BW, BH), Image.LANCZOS), np.float32)
    body = vgrad([(0, tint), (0.55, deep), (1, tint)])
    return body * 0.78 + g(bg, 3 * S) * 0.22


marble_t = noise(60, 60, 6) * 0.6 + noise(20, 20, 2) * 0.4
veins = np.abs(np.sin((np.linspace(0, 9, BW)[None, :] + marble_t * 7 + ys * 3) * np.pi))
MARBLE = np.stack([235 - (1 - veins) * 0] * 3, -1)
vein_mask = np.clip((0.12 - veins) / 0.12, 0, 1)
MARBLE = MARBLE * (1 - vein_mask[..., None]) + np.array((200, 160, 80)) * vein_mask[..., None]
brushed = noise(400, 1) * 0.5 + noise(80, 1) * 0.5
leaf = noise(6, 6, 1)

STYLES = [
    ("1 Blade crystal", lambda: finish(crystal((236, 242, 248), (170, 182, 196)), rim=(255, 255, 255), hi=1.3, lo=0.9)),
    ("2 Brushed platinum", lambda: finish(vgrad([(0, (238, 240, 244)), (0.5, (170, 174, 182)), (1, (224, 227, 232))]) * (0.86 + 0.14 * brushed[..., None]), rim=(60, 62, 70))),
    ("3 Black obsidian", lambda: finish(vgrad([(0, (58, 60, 68)), (0.45, (22, 22, 26)), (1, (8, 8, 10))]), rim=(235, 235, 240), hi=1.4, lo=0.3)),
    ("4 Rose gold", lambda: finish(vgrad([(0, (252, 214, 196)), (0.5, (196, 128, 110)), (1, (238, 184, 162))]), rim=(110, 60, 50))),
    ("5 Gold leaf", lambda: finish(vgrad([(0, (250, 226, 150)), (0.5, (196, 150, 56)), (1, (232, 196, 110))]) * (0.9 + 0.1 * leaf[..., None]), rim=(96, 66, 16))),
    ("6 Emerald glass", lambda: finish(crystal((70, 170, 120), (8, 70, 44)), rim=(214, 178, 90), hi=1.2)),
    ("7 Sapphire crystal", lambda: finish(crystal((90, 140, 230), (14, 34, 110)), rim=(225, 232, 245), hi=1.3)),
    ("8 White marble", lambda: finish(MARBLE, rim=(170, 136, 70), hi=0.7, lo=0.6)),
]
outs = []
for k, (name, fn) in enumerate(STYLES, 1):
    im = fn(); im.save(f"mat_{k}.jpg", quality=95); outs.append((name, im))
TW, TH = 540, 960
grid = Image.new("RGB", (TW * 4, (TH + 60) * 2), (14, 14, 14)); gd = ImageDraw.Draw(grid)
lf = ImageFont.truetype("~/ClipMachine/bin/mont_eb.ttf", 28)
for k, (name, im) in enumerate(outs):
    cx, cy = (k % 4) * TW, (k // 4) * (TH + 60)
    grid.paste(im.resize((TW, TH), Image.LANCZOS), (cx, cy)); gd.text((cx + 14, cy + TH + 14), name, font=lf, fill=(235, 235, 235))
grid.save("MATERIALS_8.jpg", quality=92)
Image.open("mat_1.jpg").crop((0, 1040, 1080, 1460)).save("/tmp/mat_closeup.jpg")
print("done")
